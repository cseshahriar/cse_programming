package final_exam_cse207;


public class B extends A {
	int x = 30;
}