package final_exam_cse207;

public class A {
	int x = 20;
}
